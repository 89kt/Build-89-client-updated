package client89;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Hit particles. They live in world space (so they move like real particles) and are
 * projected to the screen each frame, which is what lets the colour be fully custom.
 */
public final class HitFx {
    private static final int SQUARE = 0, STREAK = 1, STAR = 2, FLASH = 3;

    private static final class P {
        double x, y, z, vx, vy, vz, g, px, py, pz;
        float life, max, size;
        int color, kind;
    }

    private static final List<P> LIST = new ArrayList<>();
    private static final Random R = new Random();
    private static long last = System.nanoTime();

    /** Called when the player attacks an entity. */
    public static void hit(Vec3d at) {
        if (Modules.HITPARTICLES.enabled) spawn(at);
    }

    /** Shows the current style a few blocks in front of the camera (used when changing settings). */
    public static void preview() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        Vec3d cam = mc.player.getCameraPosVec(1.0f);
        Vec3d look = mc.player.getRotationVec(1.0f);
        spawn(cam.add(look.multiply(3.0)));
    }

    private static P make(Vec3d at, int color, int kind, float life, float size) {
        P p = new P();
        p.x = p.px = at.x; p.y = p.py = at.y; p.z = p.pz = at.z;
        p.color = color; p.kind = kind; p.life = p.max = life; p.size = size;
        return p;
    }

    private static void spawn(Vec3d at) {
        if (LIST.size() > 700) return;
        int style = Modules.HP_STYLE.index;
        int n = Math.round(Modules.HP_AMOUNT.value);
        float size = Modules.HP_SIZE.value;
        float sp = Modules.HP_SPEED.value;
        int entry = Theme.PALETTE[Math.max(0, Math.min(Theme.PALETTE.length - 1, Modules.HP_COLOR.index))];

        // soft flash at the impact point
        LIST.add(make(at, Theme.resolve(entry, 0f), FLASH, 0.22f, size * 3.0f));

        for (int i = 0; i < n; i++) {
            int col = Theme.resolve(entry, R.nextFloat());
            double dx = R.nextGaussian(), dy = R.nextGaussian(), dz = R.nextGaussian();
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0E-4) { dx = 0; dy = 1; dz = 0; len = 1; }
            dx /= len; dy /= len; dz /= len;
            P p;
            switch (style) {
                case 1 -> { // sparks: fast thin streaks
                    p = make(at, col, STREAK, 0.25f + R.nextFloat() * 0.25f, size);
                    double s = (5 + R.nextFloat() * 5) * sp;
                    p.vx = dx * s; p.vy = dy * s; p.vz = dz * s; p.g = 10;
                }
                case 2 -> { // ring: flat shockwave, outer + inner ring
                    p = make(at, col, SQUARE, 0.55f, size * 0.9f);
                    double a = Math.PI * 2.0 * i / n;
                    double s = (i % 3 == 0 ? 2.0 : 3.6) * sp;
                    p.vx = Math.cos(a) * s; p.vz = Math.sin(a) * s; p.vy = 0; p.g = 0;
                }
                case 3 -> { // stars: slow floaty plus-shaped sparkles
                    p = make(at, col, STAR, 0.8f + R.nextFloat() * 0.5f, size * (1.2f + R.nextFloat() * 0.8f));
                    double s = (1 + R.nextFloat() * 2) * sp;
                    p.vx = dx * s; p.vy = dy * s; p.vz = dz * s; p.g = 2.5;
                }
                case 4 -> { // fountain: shoots up and falls
                    p = make(at, col, SQUARE, 0.7f + R.nextFloat() * 0.4f, size * (0.7f + R.nextFloat() * 0.8f));
                    p.vx = (R.nextFloat() - 0.5) * 2.4 * sp; p.vz = (R.nextFloat() - 0.5) * 2.4 * sp;
                    p.vy = (4 + R.nextFloat() * 2.5) * sp; p.g = 13;
                }
                default -> { // burst
                    p = make(at, col, SQUARE, 0.5f + R.nextFloat() * 0.4f, size * (0.7f + R.nextFloat() * 0.8f));
                    double s = (1.5 + R.nextFloat() * 2.5) * sp;
                    p.vx = dx * s; p.vy = dy * s; p.vz = dz * s; p.g = 7;
                }
            }
            LIST.add(p);
        }
    }

    public static void render(DrawContext c, MinecraftClient mc, float td) {
        long now = System.nanoTime();
        float dt = Math.min((now - last) / 1.0E9f, 0.05f);
        last = now;
        if (LIST.isEmpty()) return;

        boolean first = mc.options.getPerspective().isFirstPerson();
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        Vec3d cam = mc.player.getCameraPosVec(td);

        Iterator<P> it = LIST.iterator();
        while (it.hasNext()) {
            P p = it.next();
            p.life -= dt;
            if (p.life <= 0) { it.remove(); continue; }
            p.px = p.x; p.py = p.y; p.pz = p.z;
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
            p.vy -= p.g * dt;
            if (!first) continue;

            float lf = p.life / p.max;
            float a = MathHelper.clamp(lf * 1.8f, 0f, 1f);
            Vec3d pos = new Vec3d(p.x, p.y, p.z);
            Projection.Pt pt = Projection.project(mc, td, pos, w, h);
            if (pt.behind() || pt.x() < -20 || pt.x() > w + 20 || pt.y() < -20 || pt.y() > h + 20) continue;
            double dist = cam.distanceTo(pos);
            float k = (float) MathHelper.clamp(4.0 / Math.max(dist, 0.5), 0.35, 2.5);
            int s = Math.max(1, Math.round(p.size * k));
            int x = (int) pt.x(), y = (int) pt.y();
            int col = p.color;
            int hot = Render2D.lerp(col, Theme.WHITE, 0.65f);

            switch (p.kind) {
                case SQUARE -> {
                    c.fill(x - s - 1, y - s - 1, x + s + 2, y + s + 2, Render2D.alpha(col, 0.28f * a));
                    c.fill(x - s, y - s, x + s + 1, y + s + 1, Render2D.alpha(col, a));
                    c.fill(x - s / 2, y - s / 2, x + s / 2 + 1, y + s / 2 + 1, Render2D.alpha(hot, a));
                }
                case STREAK -> {
                    Projection.Pt pp = Projection.project(mc, td, new Vec3d(p.px, p.py, p.pz), w, h);
                    if (pp.behind()) continue;
                    // stretch the streak so it reads as motion even at low speed
                    float tx = pp.x() + (x - pp.x()) * -2.0f, ty = pp.y() + (y - pp.y()) * -2.0f;
                    Render2D.line(c, tx, ty + 1, x, y + 1, Render2D.alpha(col, 0.3f * a));
                    Render2D.line(c, tx, ty, x, y, Render2D.alpha(col, a));
                    c.fill(x - 1, y - 1, x + 2, y + 2, Render2D.alpha(hot, a));
                }
                case STAR -> {
                    int arm = s * 2 + 1;
                    c.fill(x - arm, y, x + arm + 1, y + 1, Render2D.alpha(col, a));
                    c.fill(x, y - arm, x + 1, y + arm + 1, Render2D.alpha(col, a));
                    c.fill(x - arm / 2, y - arm / 2, x + arm / 2 + 1, y + arm / 2 + 1, Render2D.alpha(col, 0.35f * a));
                    c.fill(x - 1, y - 1, x + 2, y + 2, Render2D.alpha(hot, a));
                }
                default -> { // FLASH
                    int r = Math.max(2, Math.round(p.size * k * (0.6f + (1f - lf) * 1.6f)));
                    Render2D.rrect(c, x - r, y - r, r * 2, r * 2, r, Render2D.alpha(col, 0.22f * a));
                    int r2 = Math.max(1, r / 2);
                    Render2D.rrect(c, x - r2, y - r2, r2 * 2, r2 * 2, r2, Render2D.alpha(hot, 0.6f * a));
                }
            }
        }
    }
}

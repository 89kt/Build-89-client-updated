package client89;

import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

/** White + red base. The dots in the GUI swap the accent colour. */
public final class Theme {
    public static final int[] COLORS = {
        0xFFE53935, // red (default)
        0xFFC62828, // crimson
        0xFFFF4D8D, // pink
        0xFFFF8A3D, // orange
        0xFFFFC53D, // yellow
        0xFF7C5CFF, // purple
        0xFF3D8BFF, // blue
        0xFF22C7C7, // cyan
        0xFF34C759, // green
        0xFF2B2B2B  // graphite
    };
    public static int index = 0;

    /** Swatches for colour settings. 0 = follow the GUI theme, 1 = rainbow, anything else is a fixed colour. */
    public static final int[] PALETTE = {
        0, 0xFFE53935, 0xFFFF4D8D, 0xFFFF8A3D, 0xFFFFC53D, 0xFF34C759,
        0xFF22C7C7, 0xFF3D8BFF, 0xFF7C5CFF, 0xFFFFFFFF, 1
    };

    public static final int WHITE = 0xFFFFFFFF;
    public static final int PANEL = 0xF2FFFFFF;
    public static final int ROW_HOVER = 0xFFF3F3F5;
    public static final int TEXT = 0xFF222226;
    public static final int DIM = 0xFF8A8A92;
    public static final int TRACK = 0xFFE4E4E8;

    public static int accent() { return COLORS[index]; }
    /** Lighter shade of the accent, used for gradients. */
    public static int accent2() { return Render2D.lerp(accent(), WHITE, 0.38f); }

    /** Turns a PALETTE entry into a real ARGB colour. t (0..1) offsets the rainbow so every particle differs. */
    public static int resolve(int entry, float t) {
        if (entry == 0) return accent();
        if (entry == 1) {
            float h = ((Util.getMeasuringTimeMs() % 4000L) / 4000.0f + t) % 1.0f;
            return 0xFF000000 | MathHelper.hsvToRgb(h, 0.85f, 1.0f);
        }
        return entry;
    }
}

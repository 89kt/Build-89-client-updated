package client89;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Plays the chosen vanilla sound when you hit something. */
public final class HitSound {
    public static final String[] NAMES = {
        "Pling", "Bell", "Crit", "Orb", "Level Up", "Chime", "Click", "Hat", "Anvil", "Pop", "Sweep", "Bow Hit"
    };
    private static final String[] IDS = {
        "block.note_block.pling", "block.note_block.bell", "entity.player.attack.crit",
        "entity.experience_orb.pickup", "entity.player.levelup", "block.amethyst_block.chime",
        "ui.button.click", "block.note_block.hat", "block.anvil.land", "entity.item.pickup",
        "entity.player.attack.sweep", "entity.arrow.hit_player"
    };

    public static void hit() {
        if (Modules.HITSOUND.enabled) play();
    }

    public static void preview() { play(); }

    private static void play() {
        MinecraftClient mc = MinecraftClient.getInstance();
        int i = Math.max(0, Math.min(IDS.length - 1, Modules.HS_SOUND.index));
        SoundEvent ev = SoundEvent.of(Identifier.of("minecraft", IDS[i]));
        mc.getSoundManager().play(PositionedSoundInstance.master(ev, Modules.HS_PITCH.value, Modules.HS_VOLUME.value));
    }
}

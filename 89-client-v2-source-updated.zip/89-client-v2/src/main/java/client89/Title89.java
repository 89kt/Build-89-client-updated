package client89;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;

/**
 * Custom main menu: white background, huge ghost "89" pattern, blood dripping from the top,
 * rising embers, glowing logo and pill buttons. Replaces the vanilla TitleScreen (see MinecraftClientMixin).
 */
public class Title89 extends Screen {
    private static final String[] LABELS = { "Singleplayer", "Multiplayer", "89 client GUI", "Options", "Quit" };

    private final long opened = Util.getMeasuringTimeMs();
    private final float[] hover = new float[LABELS.length];

    public Title89() { super(Text.literal("89 client v2")); }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    // ---- helpers ----

    /** Deterministic pseudo random 0..1 so the animation needs no stored state. */
    private static float rnd(int i, int salt) {
        double v = Math.sin(i * 12.9898 + salt * 78.233) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    private int centerY() { return height / 2 - 20; }

    /** x, y, w, h of button i. */
    private int[] rect(int i) {
        int bw = 200, h = 20, gap = 5;
        int x = width / 2 - bw / 2;
        int y0 = centerY() + 34;
        if (i < 3) return new int[] { x, y0 + i * (h + gap), bw, h };
        int half = (bw - 6) / 2;
        int y = y0 + 3 * (h + gap);
        return i == 3 ? new int[] { x, y, half, h } : new int[] { x + half + 6, y, half, h };
    }

    private double mouseX() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.mouse.getX() * mc.getWindow().getScaledWidth() / (double) mc.getWindow().getWidth();
    }
    private double mouseY() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.mouse.getY() * mc.getWindow().getScaledHeight() / (double) mc.getWindow().getHeight();
    }

    // ---- drawing ----

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        TextRenderer tr = textRenderer;
        long now = Util.getMeasuringTimeMs();
        long t = now - opened;
        float fade = Render2D.ease(MathHelper.clamp(t / 600.0f, 0f, 1f));
        int red = Theme.accent();
        int w = width, h = height;

        // base: white -> faint tinted white
        c.fillGradient(0, 0, w, h, 0xFFFFFFFF, Render2D.lerp(0xFFFFFFFF, red, 0.10f));
        c.fillGradient(0, h - h / 3, w, h, Render2D.alpha(red, 0f), Render2D.alpha(red, 0.16f * fade));

        Matrix3x2fStack m = c.getMatrices();

        // ghost "89" tiles drifting diagonally
        int tw = 150, th = 84;
        float off = (now * 0.012f) % tw;
        for (int iy = -1; iy <= h / th + 1; iy++) {
            for (int ix = -2; ix <= w / tw + 1; ix++) {
                float x = ix * tw + off + (iy % 2 == 0 ? 0 : tw / 2f);
                float y = iy * th + off * 0.55f;
                m.pushMatrix();
                m.translate(x, y);
                m.scale(3.0f, 3.0f);
                c.drawText(tr, "89", 0, 0, Render2D.alpha(red, 0.055f * fade), false);
                m.popMatrix();
            }
        }

        // rising embers
        for (int i = 0; i < 40; i++) {
            float period = 6000f + rnd(i, 3) * 6000f;
            float p = ((now + rnd(i, 4) * period) % period) / period;
            float ex = rnd(i, 1) * w + (float) Math.sin(now * 0.001 * (0.5 + rnd(i, 2)) + i) * 12f;
            float ey = h - p * (h + 30) + 10;
            int s = 1 + (int) (rnd(i, 5) * 2.5f);
            float al = (float) Math.sin(p * Math.PI) * (0.35f + 0.5f * rnd(i, 6)) * fade;
            int xi = (int) ex, yi = (int) ey;
            c.fill(xi - s - 1, yi - s - 1, xi + s + 2, yi + s + 2, Render2D.alpha(red, 0.18f * al));
            c.fill(xi - s, yi - s, xi + s + 1, yi + s + 1, Render2D.alpha(Render2D.lerp(red, Theme.WHITE, 0.3f), al));
        }

        // logo (parallax follows the mouse a little)
        float px = (mx - w / 2f) / w * 6f, py = (my - h / 2f) / h * 4f;
        float pulse = (float) (Math.sin(now * 0.0025) * 0.5 + 0.5);
        float ls = 8.0f * (0.85f + 0.15f * fade);
        float lx = w / 2f + px, ly = centerY() - 30 + py;
        String big = "89";
        for (int k = 3; k >= 1; k--) {
            drawScaled(c, tr, big, lx, ly, ls + 0.45f * k * (0.6f + pulse * 0.8f), Render2D.alpha(red, 0.07f * fade));
        }
        drawScaled(c, tr, big, lx + 0.5f * 1.2f, ly + 0.7f * 1.2f, ls, Render2D.alpha(0xFF5A0A0A, 0.35f * fade));
        drawScaled(c, tr, big, lx, ly, ls, Render2D.alpha(Render2D.lerp(red, Theme.accent2(), pulse * 0.35f), fade));

        // subtitle
        m.pushMatrix();
        m.translate(w / 2f + px * 0.5f, centerY() + 12 + py * 0.5f);
        m.scale(1.8f, 1.8f);
        Render2D.wave(c, tr, "client v2", -tr.getWidth("client v2") / 2, 0, fade);
        m.popMatrix();

        // blood: band at the top + drips
        c.fillGradient(0, 0, w, 6, Render2D.alpha(Render2D.lerp(red, 0xFF000000, 0.35f), fade), Render2D.alpha(red, fade));
        int drips = Math.max(8, w / 22);
        for (int i = 0; i < drips; i++) {
            int x = (int) (rnd(i, 10) * (w - 8)) + 2;
            float maxLen = 14 + rnd(i, 11) * 50;
            float ph = (float) (Math.sin(now * 0.0008 * (0.5 + rnd(i, 12)) + rnd(i, 13) * 6.28) * 0.5 + 0.5);
            int len = (int) (maxLen * (0.25f + 0.75f * ph) * fade);
            int dw = 3 + (int) (rnd(i, 14) * 2);
            if (len < 4) continue;
            Render2D.rrect(c, x, 0, dw, len, dw / 2, red);
            Render2D.rrect(c, x - 1, len - 2, dw + 2, dw + 3, (dw + 2) / 2, red);
            c.fill(x + 1, 3, x + 2, Math.max(4, len - 3), Render2D.alpha(Theme.WHITE, 0.35f));
        }

        // buttons
        double dmx = mx, dmy = my;
        for (int i = 0; i < LABELS.length; i++) {
            int[] r = rect(i);
            float in = Render2D.ease(MathHelper.clamp((t - 200 - i * 90) / 450.0f, 0f, 1f));
            int bx = r[0] + (int) ((1f - in) * 30f * (i % 2 == 0 ? -1 : 1));
            boolean hov = dmx >= r[0] && dmx < r[0] + r[2] && dmy >= r[1] && dmy < r[1] + r[3];
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * 0.25f;
            float hv = hover[i];
            Render2D.rrect(c, bx - 1, r[1] - 1, r[2] + 2, r[3] + 2, 7, Render2D.alpha(red, (0.25f + 0.55f * hv) * in));
            Render2D.rrect(c, bx, r[1], r[2], r[3], 6, Render2D.alpha(Theme.PANEL, in));
            Render2D.rrect(c, bx, r[1], r[2], r[3], 6, Render2D.alpha(red, hv * in));
            int tcol = Render2D.lerp(Theme.TEXT, Theme.WHITE, hv);
            Render2D.centered(c, tr, LABELS[i], bx + r[2] / 2, r[1] + 6, Render2D.alpha(tcol, in), false);
        }

        // footer
        Render2D.centered(c, tr, "made by 89_kt", w / 2, h - 14, Render2D.alpha(Theme.DIM, fade), false);
        c.drawText(tr, "Minecraft 1.21.11", 6, h - 14, Render2D.alpha(Theme.DIM, fade), false);
        String v = "89 client v2.0.0";
        c.drawText(tr, v, w - 6 - tr.getWidth(v), h - 14, Render2D.alpha(Theme.DIM, fade), false);
    }

    /** Draws text centred on (cx, cy) at the given scale. */
    private static void drawScaled(DrawContext c, TextRenderer tr, String s, float cx, float cy, float scale, int color) {
        Matrix3x2fStack m = c.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(scale, scale);
        c.drawText(tr, s, -tr.getWidth(s) / 2, -4, color, false);
        m.popMatrix();
    }

    // ---- input ----

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            double mx = mouseX(), my = mouseY();
            for (int i = 0; i < LABELS.length; i++) {
                int[] r = rect(i);
                if (mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3]) {
                    client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                    act(i);
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    private void act(int i) {
        switch (i) {
            case 0 -> client.setScreen(new SelectWorldScreen(this));
            case 1 -> client.setScreen(new MultiplayerScreen(this));
            case 2 -> client.setScreen(new ClickGui(this));
            case 3 -> client.setScreen(new OptionsScreen(this, client.options));
            default -> client.scheduleStop();
        }
    }
}

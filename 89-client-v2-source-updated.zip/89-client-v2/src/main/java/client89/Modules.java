package client89;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

public final class Modules {
    // ---- Render ----
    public static final Module NAMETAGS = new Module("Render", "Nametags", "Name, hands, armor", true)
        .setting(new Module.Setting("Range", 32f, 500f, 500f, 0));
    public static final Module TRACERS = new Module("Render", "Tracers", "Lines to players", true)
        .setting(new Module.Setting("Range", 32f, 1000f, 1000f, 0));

    // ---- Effects: hit particles ----
    public static final Module.Setting HP_STYLE = Module.Setting.choice("Style", 0,
        "Burst", "Sparks", "Ring", "Stars", "Fountain").onChange(HitFx::preview);
    public static final Module.Setting HP_COLOR = Module.Setting.color("Color", 1).onChange(HitFx::preview);
    public static final Module.Setting HP_AMOUNT = new Module.Setting("Amount", 4f, 40f, 16f, 0);
    public static final Module.Setting HP_SIZE = new Module.Setting("Size", 1f, 4f, 2f, 1);
    public static final Module.Setting HP_SPEED = new Module.Setting("Speed", 0.5f, 2f, 1f, 1);
    public static final Module HITPARTICLES = new Module("Effects", "HitParticles", "Particles when you hit", true)
        .setting(HP_STYLE).setting(HP_COLOR).setting(HP_AMOUNT).setting(HP_SIZE).setting(HP_SPEED);

    // ---- Effects: hit sound ----
    public static final Module.Setting HS_SOUND = Module.Setting.choice("Sound", 0,
        HitSound.NAMES).onChange(HitSound::preview);
    public static final Module.Setting HS_VOLUME = new Module.Setting("Volume", 0.1f, 2f, 1f, 1).onChange(HitSound::preview);
    public static final Module.Setting HS_PITCH = new Module.Setting("Pitch", 0.5f, 2f, 1f, 1).onChange(HitSound::preview);
    public static final Module HITSOUND = new Module("Effects", "HitSound", "Sound when you hit", true)
        .setting(HS_SOUND).setting(HS_VOLUME).setting(HS_PITCH);

    // ---- HUD ----
    public static final Module WATERMARK = new Module("HUD", "Watermark", "89 client v2 + FPS", true);
    public static final Module MODULELIST = new Module("HUD", "ModuleList", "Enabled modules on screen", true);
    public static final Module NAMESCALE = new Module("HUD", "TagScale", "Nametag size", true)
        .setting(new Module.Setting("Scale", 0.5f, 2.0f, 1.0f, 1));

    // ---- Client ----
    public static final Module DISCORD = new Module("Client", "DiscordRPC", "Show 89 client on Discord", true)
        .setting(Module.Setting.choice("Server IP", 0, "Show", "Hide"));

    public static final List<Module> ALL = List.of(
        NAMETAGS, TRACERS, HITPARTICLES, HITSOUND, WATERMARK, MODULELIST, NAMESCALE, DISCORD);
    public static final List<String> CATEGORIES = List.of("Render", "Effects", "HUD", "Client");

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("89-client.properties"); }

    private static String key(Module m, Module.Setting s) { return m.name + "." + s.name; }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) { p.load(in); }
            for (Module m : ALL) {
                String v = p.getProperty(m.name);
                if (v != null) { m.enabled = Boolean.parseBoolean(v); m.anim = m.enabled ? 1f : 0f; }
                for (Module.Setting s : m.settings) {
                    String raw = p.getProperty(key(m, s));
                    // old configs stored the single slider as "<Module>.value"
                    if (raw == null && s == m.setting) raw = p.getProperty(m.name + ".value");
                    if (raw == null) continue;
                    try {
                        switch (s.kind) {
                            case SLIDER -> s.value = Math.max(s.min, Math.min(s.max, Float.parseFloat(raw)));
                            case CHOICE -> s.index = Math.max(0, Math.min(s.options.length - 1, Integer.parseInt(raw)));
                            case COLOR -> s.index = Math.max(0, Math.min(Theme.PALETTE.length - 1, Integer.parseInt(raw)));
                        }
                    } catch (NumberFormatException ignored) { }
                }
            }
            String t = p.getProperty("theme");
            if (t != null) Theme.index = Math.max(0, Math.min(Theme.COLORS.length - 1, Integer.parseInt(t)));
            String id = p.getProperty("discord.clientId");
            if (id != null && !id.isBlank()) Discord.clientId = id.trim();
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Module m : ALL) {
                p.setProperty(m.name, String.valueOf(m.enabled));
                for (Module.Setting s : m.settings) {
                    String v = s.kind == Module.Setting.Kind.SLIDER ? String.valueOf(s.value) : String.valueOf(s.index);
                    p.setProperty(key(m, s), v);
                }
            }
            p.setProperty("theme", String.valueOf(Theme.index));
            p.setProperty("discord.clientId", Discord.clientId);
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "89 client v2"); }
        } catch (Exception ignored) { }
    }
}

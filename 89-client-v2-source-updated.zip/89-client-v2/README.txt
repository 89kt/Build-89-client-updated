89 client v2  -  made by 89_kt
==============================

BUILD (Windows):  open a terminal in this folder and run
    gradlew build        (see step 1 if there is no gradlew file)
The jar appears in  build/libs/89-client-2.0.0.jar   (NOT the -sources one).
Put it in .minecraft/mods together with Fabric API (Minecraft 1.21.11, Fabric Loader 0.17+).

1) No gradlew? Easiest: download the Fabric example mod from https://fabricmc.net/develop/template/
   (1.21.11, Yarn mappings), then copy these into it, replacing the same-named files:
     src/            build.gradle   gradle.properties   settings.gradle
   Then run:  gradlew build

2) If Gradle complains about a version, open https://fabricmc.net/develop , pick 1.21.11,
   and copy yarn_mappings / loader_version / fabric_api_version into gradle.properties.

CONTROLS
   P            open / close the GUI
   left click   toggle a module
   right click  open a module's settings (sliders)
   dots         change GUI colour (also recolours the title screen)
   search bar   filter modules (P does not close the GUI while typing)

Config is saved in  .minecraft/config/89-client.properties


NEW IN THIS VERSION
   - Custom title screen (replaces the vanilla one)
   - SkyColor module removed
   - HitParticles module: Style (Burst/Sparks/Ring/Stars/Fountain), Color (theme / fixed / rainbow),
     Amount, Size, Speed.  Changing a setting shows a preview.
   - HitSound module: 12 sounds, Volume, Pitch.  Changing a setting plays a preview.
   - DiscordRPC module (Client panel): shows "89 client v2" + where you are playing.

DISCORD SETUP (one time)
   1. https://discord.com/developers/applications -> New Application -> name it:  89 client
   2. Copy the Application ID.
   3. Put it in src/main/java/client89/Discord.java (DEFAULT_CLIENT_ID), OR after the first launch
      into .minecraft/config/89-client.properties as   discord.clientId=123456789012345678
   4. Rich Presence -> Art Assets -> upload discord-icon-1024.png with the key:  logo89
   (Discord can take a few minutes to show newly uploaded art.)
